import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class EmailFormat {

	public JFrame frame;
	public static String applicantID;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EmailFormat window = new EmailFormat(applicantID);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public EmailFormat(String applicantID) {
		initialize(applicantID);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String applicantID) {
		frame = new JFrame();
		frame.setBounds(100, 100, 1300, 800);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		//BUTTON ====================================================================================

		JButton Return = new JButton("");
		Return.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ApplicantHomeTab homeTab = new ApplicantHomeTab(applicantID);
				homeTab.setVisible(true);
				frame.dispose();
				
				
			}
		});
		Return.setIcon(new ImageIcon("C:\\Users\\tyrel\\Downloads\\NCVAProject\\NCVASystemUI\\Buttons\\Job Posting\\Return (ADMIN)_ .png"));
		Return.setBounds(1172, 93, 122, 44);
		Return.setOpaque(false);
		Return.setContentAreaFilled(false);
		Return.setBorderPainted(false);
		frame.getContentPane().add(Return);
		
		//BACKGROUND ====================================================================================

		JLabel Background = new JLabel("");
		Background.setIcon(new ImageIcon("C:\\Users\\tyrel\\Downloads\\NCVAProject\\NCVASystemUI\\Pages\\EMAIL_FORMAT.png"));
		Background.setBounds(0, 0, 1300, 800);
		frame.getContentPane().add(Background);
	}
}