import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTextField;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JScrollPane;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.Color;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class JobPosting {

	public JFrame JobPosting;
	private JTextField PosCode;
	public JTextField JobTitle;
	private JTextField Responsibilities;
	private JTextField Salary;
	private JTable table_1;
	private JScrollPane scrollPane;
    private JTable dash_table;
	private JTable App_table;
	DefaultTableModel model;
	private String urlToDatabase = "jdbc:mysql://localhost:3306/NCVAProjectsSystemDatabase";

    
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JobPosting window = new JobPosting();
					window.JobPosting.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	//METHODS ====================================================================================


    
   // ====================================================================================

	/**
	 * Create the application.
	 */
	public JobPosting() {
        this.dash_table = dash_table;
        this.App_table = App_table;
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		JobPosting = new JFrame();
		JobPosting.setBounds(100, 100, 1300, 800);
		JobPosting.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JobPosting.setResizable(false);
		JobPosting.setLocationRelativeTo(null);
		JobPosting.getContentPane().setLayout(null);
		
		//TEXT FIELDS ====================================================================================
		
		//Position Code
		PosCode = new JTextField();
		PosCode.setBounds(1015, 261, 237, 60);
		PosCode.setBackground(new Color(228, 228, 228));
		JobPosting.getContentPane().add(PosCode);
		PosCode.setColumns(10);
		
		//Job Title
		JobTitle = new JTextField();
		JobTitle.setBounds(1016, 343, 236, 62);
		JobTitle.setBackground(new Color(228, 228, 228));
		JobPosting.getContentPane().add(JobTitle);
		JobTitle.setColumns(10);
		
		//Responsibilites
		Responsibilities = new JTextField();
		Responsibilities.setBounds(1016, 423, 236, 61);
		Responsibilities.setBackground(new Color(228, 228, 228));
		JobPosting.getContentPane().add(Responsibilities);
		Responsibilities.setColumns(10);
		
		//Salary
		Salary = new JTextField();
		Salary.setBounds(1016, 498, 235, 60);
		Salary.setBackground(new Color(228, 228, 228));
		Salary.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				
				String SalaryNum = Salary.getText();

				//get length of string
				int length = SalaryNum.length();
				
				char c = e.getKeyChar();
				
				//check for numbers 0-9
				if (e.getKeyChar() >= '0' && e.getKeyChar() <= '9') {
					
					if(length<6) {
						//Editable 
						Salary.setEditable(true);
					
					} else {
						//Not editable if lenghth is more than 6
						Salary.setEditable(false);
					}
					
				} else if (e.getExtendedKeyCode()== KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()== KeyEvent.VK_DELETE) {
					
					Salary.setEditable(true);
					
				} else {
					
					Salary.setEditable(false);
					JOptionPane.showMessageDialog(null,"Only Input Numbers from 0 to 9");

				}						
			}

		});
		JobPosting.getContentPane().add(Salary);
		Salary.setColumns(10);
		
		
		//Scroll Panel ====================================================================================

		//Add JScrollPane to show values in table
		scrollPane = new JScrollPane();
		scrollPane.setBounds(49, 213, 782, 504);
		scrollPane.addMouseListener(new MouseAdapter() {	
		public void mouseClicked(MouseEvent e) {
				
				int i = table_1.getSelectedRow();
				PosCode.setText(model.getValueAt(i, 0).toString());
				JobTitle.setText(model.getValueAt(i, 1).toString());
				Responsibilities.setText(model.getValueAt(i, 2).toString());
				Salary.setText(model.getValueAt(i, 3).toString());
			}
		});
		JobPosting.getContentPane().add(scrollPane);
		
		//TABLE ====================================================================================
		
		table_1 = new JTable();
		table_1.setShowGrid(true);
		table_1.setShowHorizontalLines(true);
		table_1.setGridColor(Color.black);  
		table_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				int i = table_1.getSelectedRow();
				PosCode.setText(model.getValueAt(i,0).toString());
				JobTitle.setText(model.getValueAt(i,1).toString());
				Responsibilities.setText(model.getValueAt(i,2).toString());
				Salary.setText(model.getValueAt(i,3).toString());

			}
		});
		model = new DefaultTableModel();
		Object[] column = {"       Position Code","          Job Title", "    Responsibilities", "            Salary"};
		final Object[] row = new Object[4];
		model.setColumnIdentifiers(column);
		table_1.setModel(model);
		scrollPane.setViewportView(table_1);
		
		//BUTTONS ====================================================================================
						
		
		//ADD BUTTON
		JButton Add = new JButton("");
		Add.setBorder(null);
		Add.setIcon(new ImageIcon("C:\\Users\\tyrel\\Downloads\\NCVAProject\\NCVASystemUI\\Buttons\\Job Posting\\POSTING (ADD)_ .png"));
		Add.setBounds(910, 603, 102, 40);
		Add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int checkCode = Integer.parseInt(PosCode.getText());
				String checkTitle = JobTitle.getText();
				
				boolean exists = ifExistsInDatabase(checkCode, checkTitle);
				
				if (!exists) {
					int result = JOptionPane.showConfirmDialog(table_1, "Review your added inputs first. Are you sure that the data that you've entered is correct?", 
			    			"Adding Confirmation Window", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
					if (result == JOptionPane.YES_OPTION) {
						int posCode = Integer.parseInt(PosCode.getText());
						String title = JobTitle.getText();
						String tasks = Responsibilities.getText();
						float salary = Float.parseFloat(Salary.getText());
		            	String url = "jdbc:sqlserver://DESKTOP-8OC2E7P\\sqlexpress:1433;databaseName=NCVADatabase2;integratedSecurity=true;encrypt=true;trustServerCertificate=true;authenticationScheme=NativeAuthentication";

						try {
		            		Connection connection = DriverManager.getConnection(url);
		            		
//		            		String insertQuery = "INSERT INTO JobPosition (JobID, Title, Task, Salary)"
//		            				+ " VALUES('" + posCode + "','" + title + "','" + tasks + "','" + salary + "')";
		            		String insertQuery = "INSERT INTO JobPosition (JobID, Title, Task, Salary) VALUES(?, ?, ?, ?)";
		            		
		            		
		            		PreparedStatement add = connection.prepareStatement(insertQuery);
		            		
		            		add.setInt(1, posCode);
		            		add.setString(2, title);
		            		add.setString(3, tasks);
		            		add.setFloat(4, salary);

		            		int x = add.executeUpdate();
		            		// Should probably check what this does.
		            		if (x == 0) {
		            			JOptionPane.showMessageDialog(Add, "An error has occured: Failed to add record.");
		            		} else {
		            			JOptionPane.showMessageDialog(Add, "Inputted job position has been successfully added!");
		            		}
		            		add.close();
		            		connection.close();
		            	} catch (Exception ex) {
		            		ex.printStackTrace();
		            	}
					} else {
						JOptionPane.showMessageDialog(Add, "Adding of input canceled.");
					}
				} else {
					JOptionPane.showMessageDialog(Add, "Warning! The entered position code or title already exists within the database. Please review the table first before adding the position.");
				}	
				
			} 

		});
		JobPosting.getContentPane().add(Add);
		
		//UPDATE BUTTON
		JButton Update = new JButton("");
		Update.setBorder(null);
		Update.setIcon(new ImageIcon("C:\\Users\\tyrel\\Downloads\\NCVAProject\\NCVASystemUI\\Buttons\\Job Posting\\POSTING (UPDATE)  _ .png"));
		Update.setBounds(1033, 603, 102, 40);
		Update.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				// Check first if there's a selected row on the table
				// Check for inputs in the textfields
				// Verify with the user if the information inputted on the fields are what they would want.
				// If yes, proceed to update the table
				int selectedRow = table_1.getSelectedRow();
				
				if (selectedRow >= 0) {
					if (!(PosCode.getText().isBlank()) && !(JobTitle.getText().isBlank()) && !(Responsibilities.getText().isBlank()) 
							&& !(Salary.getText().isBlank())) {
						int result = JOptionPane.showConfirmDialog(table_1, "Review your updated inputs first. Are you sure that the data that you've entered is correct?", 
		    			"Update Confirmation Window", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
						if (result == JOptionPane.YES_OPTION) {
							String title = JobTitle.getText();
							String tasks = Responsibilities.getText();
							float salary = Float.parseFloat(Salary.getText());
							
							
							String originalCode = (String) table_1.getValueAt(selectedRow, 0);
							
							boolean exists = ifTitleExistsInDatabase(title);
			            	String url = "jdbc:sqlserver://DESKTOP-8OC2E7P\\sqlexpress:1433;databaseName=NCVADatabase2;integratedSecurity=true;encrypt=true;trustServerCertificate=true;authenticationScheme=NativeAuthentication";

							if (!exists) {
								try {
				            		Connection connection = DriverManager.getConnection(url);
				            		
				            		
				            		// There might be a possibility that Position Code would not or cannot be changed.
//				            		String updateQuery = "UPDATE JobPosition SET JobID = '" + posCode + "', Title = '" + title + "', "
//				            				+ "Task = '" + tasks + "', Salary = '" + salary + "' WHERE JobID = " + originalCode + ";";
				            		String updateQuery = "UPDATE JobPosition SET Title = ?, Task = ?, Salary = ? WHERE JobID = ?";
				            		
				            		PreparedStatement update = connection.prepareStatement(updateQuery);
				            		
				            		update.setString(1, title);
				            		update.setString(2, tasks);
				            		update.setFloat(3, salary);
				            		update.setInt(4, Integer.valueOf(originalCode));
				            		
				            		// Should add check-case to see if inputted record already exists.
				            		int x = update.executeUpdate();
				            		// Should probably check what this does.
				            		if (x == 0) {
				            			JOptionPane.showMessageDialog(Update, "An error has occured: Failed to update database.");
				            		} else {
				            			JOptionPane.showMessageDialog(Update, "Inputted information has been successfully added and updated!");
				            		}
				            		update.close();
				            		connection.close();
				            	} catch (Exception ex) {
				            		ex.printStackTrace();
				            	}

							} else {
								JOptionPane.showMessageDialog(Update, "Warning! The entered title already exists within the database. Please review the updated inputs to ensure there are no conflicts with existing data.");
							}
							
						} else {
							JOptionPane.showMessageDialog(Update, "Updating of selected row canceled.");
						}
					} else {
						JOptionPane.showMessageDialog(Update, "Make sure that there are no empty values.");
					}
			    } else {
					JOptionPane.showMessageDialog(Update, "Please select a line in the table first.");
			    }
						
			}
		});
		JobPosting.getContentPane().add(Update);
		
		//DELETE BUTTON
		JButton Delete = new JButton("");
		Delete.setBorder(null);
		Delete.setIcon(new ImageIcon("C:\\Users\\tyrel\\Downloads\\NCVAProject\\NCVASystemUI\\Buttons\\Job Posting\\POSTING (DELETE)  _ .png"));
		Delete.setBounds(1018, 677, 117, 40);
		Delete.setBackground(Color.RED);
		Delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			    int selectedRow = table_1.getSelectedRow();
			    
			    if (selectedRow >= 0) {
			        if (!(PosCode.getText().isBlank()) && !(JobTitle.getText().isBlank()) && !(Responsibilities.getText().isBlank()) 
			                && !(Salary.getText().isBlank())) {
			            int result = JOptionPane.showConfirmDialog(table_1, "Review your selections first. Are you sure that you want to delete this data/row from the database?", 
			            "Delete Confirmation Window", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
			            if (result == JOptionPane.YES_OPTION) {
			                int posCode = Integer.parseInt(PosCode.getText());

			                String url = "jdbc:sqlserver://DESKTOP-8OC2E7P\\sqlexpress:1433;databaseName=NCVADatabase2;integratedSecurity=true;encrypt=true;trustServerCertificate=true;authenticationScheme=NativeAuthentication";

			                try {
			                    Connection connection = DriverManager.getConnection(url);

			                    // Delete associated JobApplication records
			                    String deleteJobApplicationQuery = "DELETE FROM JobApplication WHERE JobID = ?";
			                    PreparedStatement deleteJobApplicationStatement = connection.prepareStatement(deleteJobApplicationQuery);
			                    deleteJobApplicationStatement.setInt(1, posCode);
			                    deleteJobApplicationStatement.executeUpdate();
			                    deleteJobApplicationStatement.close();

			                    // Then delete the JobPosition record
			                    String deleteJobPositionQuery = "DELETE FROM JobPosition WHERE JobID = ?";
			                    PreparedStatement deleteJobPositionStatement = connection.prepareStatement(deleteJobPositionQuery);
			                    deleteJobPositionStatement.setInt(1, posCode);
			                    int x = deleteJobPositionStatement.executeUpdate();

			                    if (x == 0) {
			                        JOptionPane.showMessageDialog(Delete, "An error has occurred: Failed to delete data from the database.");
			                    } else {
			                        JOptionPane.showMessageDialog(Delete, "Selected information has been successfully removed!");
			                    }
			                    deleteJobPositionStatement.close();
			                    connection.close();
			                } catch (Exception ex) {
			                    ex.printStackTrace();
			                }
			            } else {
			                JOptionPane.showMessageDialog(Delete, "Deleting of selected row canceled.");
			            }
			        } else {
			            //JOptionPane.showMessageDialog(Delete, "Make sure that there are no empty values. If there are, indicate it with N/A");
			        }
			    } else {
			        JOptionPane.showMessageDialog(Delete, "Please select a line in the table first");
			    }
			}


		});
		JobPosting.getContentPane().add(Delete);
		
		//CLEAR BUTTON
		JButton Clear = new JButton("");
		Clear.setBorder(null);
		Clear.setIcon(new ImageIcon("C:\\Users\\tyrel\\Downloads\\NCVAProject\\NCVASystemUI\\Buttons\\Job Posting\\POSTING (CLEAR)  _ .png"));
		Clear.setBounds(1158, 603, 108, 40);
		Clear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				PosCode.setText("");
				JobTitle.setText("");
				Responsibilities.setText("");
				Salary.setText("");
			}
		});
		JobPosting.getContentPane().add(Clear);
		
		//RETURN BUTTON
		JButton btn_Return = new JButton("");
		btn_Return.setBorder(null);
		btn_Return.setBounds(1179, 94, 100, 42);
		btn_Return.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ExecutiveDashboard ExecutiveDash = new ExecutiveDashboard();
				ExecutiveDash.ExecutiveDashboard.setVisible(true);
				JobPosting.dispose();
                			
			}
		});
		btn_Return.setIcon(new ImageIcon("C:\\Users\\tyrel\\Downloads\\NCVAProject\\NCVASystemUI\\Buttons\\Job Posting\\Return (ADMIN)_ .png"));
		JobPosting.getContentPane().add(btn_Return);
		
		DefaultTableModel tableModel = (DefaultTableModel)table_1.getModel();
		
		JButton btnViewTable = new JButton("View / Refresh");
		btnViewTable.setBounds(30, 152, 127, 29);
		btnViewTable.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Clear table first
				tableModel.setRowCount(0);
            	String url = "jdbc:sqlserver://DESKTOP-8OC2E7P\\sqlexpress:1433;databaseName=NCVADatabase2;integratedSecurity=true;encrypt=true;trustServerCertificate=true;authenticationScheme=NativeAuthentication";

				try {
					Connection connection = DriverManager.getConnection(url);
					
					Statement st = connection.createStatement();
					
					String sqlQuery = "SELECT * FROM JobPosition";
					ResultSet rs = st.executeQuery(sqlQuery);
					
					while (rs.next()) {
						// Data from the database will continue to be added until it reaches the end
						String jobID = String.valueOf(rs.getInt("JobID")); // Conversion due to int value
						String jobTitle = rs.getString("Title");
						String jobTask = rs.getString("Task"); 
						String jobSalary = String.valueOf(rs.getFloat("Salary"));
						
						// String array to store data into the JTable
						String tableData[] = {jobID, jobTitle, jobTask, jobSalary};
						
						
						// Add string array data into JTable
						tableModel.addRow(tableData);
					}
					st.close();
					connection.close();
				} catch(Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		JobPosting.getContentPane().add(btnViewTable);
		
		
	
		//BACKGROUND====================================================================================

		JLabel lblJobPosting_BG = new JLabel("");
		lblJobPosting_BG.setBounds(0, 0, 1300, 800);
		lblJobPosting_BG.setIcon(new ImageIcon("C:\\Users\\tyrel\\Downloads\\NCVAProject\\NCVASystemUI\\Pages\\JOB POSTING (ADMIN).png"));
		JobPosting.getContentPane().add(lblJobPosting_BG);
					

	}
	
	// Checks if the inputted position code or job title already exists in the JobPosition table.
	private boolean ifExistsInDatabase(int checkCode, String checkTitle) {
		String checkQuery = "SELECT * FROM JobPosition WHERE JobID = ? OR Title = ?";
    	String url = "jdbc:sqlserver://DESKTOP-8OC2E7P\\sqlexpress:1433;databaseName=NCVADatabase2;integratedSecurity=true;encrypt=true;trustServerCertificate=true;authenticationScheme=NativeAuthentication";

    	try {
    		Connection check = DriverManager.getConnection(url);
    		
    		PreparedStatement loginSt = check.prepareStatement(checkQuery);
    		
    		loginSt.setInt(1, checkCode);
    		loginSt.setString(2, checkTitle);
    		
    		ResultSet rs = loginSt.executeQuery();
    		
    		// This section means that there was a match and that the user's inputted position code or title already
    		// exists within the database. Else, it will simply close the Connection and PreparedStatement and proceed
    		// to return false.
    		if (rs.next()) {
    			loginSt.close();
        		check.close();
    			return true;
    		} else {
    			loginSt.close();
        		check.close();
    		}
    		
    	} catch (Exception ex) {
    		ex.printStackTrace();
    	} 

    	return false;
	}
	
	private boolean ifTitleExistsInDatabase(String checkTitle) {
		String checkQuery = "SELECT * FROM JobPosition WHERE Title = ?";
    	String url = "jdbc:sqlserver://DESKTOP-8OC2E7P\\sqlexpress:1433;databaseName=NCVADatabase2;integratedSecurity=true;encrypt=true;trustServerCertificate=true;authenticationScheme=NativeAuthentication";

    	try {
    		Connection check = DriverManager.getConnection(url);
    		
    		PreparedStatement loginSt = check.prepareStatement(checkQuery);
    		
    		loginSt.setString(1, checkTitle);
    		
    		ResultSet rs = loginSt.executeQuery();
    		
    		// This section means that there was a match and that the user's inputted position code or title already
    		// exists within the database. Else, it will simply close the Connection and PreparedStatement and proceed
    		// to return false.
    		if (rs.next()) {
    			loginSt.close();
        		check.close();
    			return true;
    		} else {
    			loginSt.close();
        		check.close();
    		}
    		
    	} catch (Exception ex) {
    		ex.printStackTrace();
    	} 

    	return false;
	}
	
}