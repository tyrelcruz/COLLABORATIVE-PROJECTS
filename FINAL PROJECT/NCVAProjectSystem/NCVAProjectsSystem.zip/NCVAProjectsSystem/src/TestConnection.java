

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class TestConnection {

    static {
        try {
            // Set the java.library.path to the directory containing the DLLs
            String libraryPath = "C:\\Users\\tyrel\\Downloads\\NCVAProject\\NCVAProjectsSystem";
            System.setProperty("java.library.path", libraryPath);
            
            // Load the authentication DLL manually
            System.load(libraryPath + "/mssql-jdbc_auth-12.6.1.x64.dll");
        } catch (UnsatisfiedLinkError e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
    	String url = "jdbc:sqlserver://DESKTOP-8OC2E7P\\sqlexpress:1433;databaseName=NCVADatabase;integratedSecurity=true;encrypt=true;trustServerCertificate=true;authenticationScheme=NativeAuthentication";


        try {
            Connection connection = DriverManager.getConnection(url);
            System.out.println("Connected to Microsoft SQL Server");
        } catch (SQLException e) {
            System.out.println("Oops, there's an error: ");
            e.printStackTrace();
        }
    }
}