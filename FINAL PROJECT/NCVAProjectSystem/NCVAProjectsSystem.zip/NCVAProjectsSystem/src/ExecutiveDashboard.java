import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Color;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.JScrollPane;
import java.io.File;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.Map;
import java.util.HashMap;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.JComboBox;
import javax.swing.ComboBoxModel;

public class ExecutiveDashboard {

    public JFrame ExecutiveDashboard;
    
    //Added Positions
    private DefaultTableModel model;
    private JTable dash_table;
    
    //Applicant Count
    private JPanel AppStatus;
    

    
    private DefaultTableModel applicantTableModel;
    
    private JTable applicantTable;
    private JTextField textFieldName;
    private JTextField textFieldPosition;
    
    private JScrollPane applicantScrollPane;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ExecutiveDashboard window = new ExecutiveDashboard();
					window.ExecutiveDashboard.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
    public ExecutiveDashboard() {
        initialize();
    }
    public JTable getTable() {
        return dash_table;
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
    	ExecutiveDashboard = new JFrame();
    	ExecutiveDashboard.setBounds(100, 100, 1300, 800);
    	ExecutiveDashboard.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	ExecutiveDashboard.setResizable(false);
    	ExecutiveDashboard.setLocationRelativeTo(null);
    	ExecutiveDashboard.getContentPane().setLayout(null);

        
        // Tables ====================================================================================

	    // Added Positions
        model = new DefaultTableModel();
	    
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(24, 231, 593, 523);
        ExecutiveDashboard.getContentPane().add(scrollPane);
        
        dash_table = new JTable();
        scrollPane.setViewportView(dash_table);
        dash_table.setModel(model);       
        dash_table.setShowGrid(true);
        dash_table.setShowHorizontalLines(true);
        dash_table.setGridColor(Color.black);   
        dash_table.setEnabled(false);
        dash_table.setFocusable(false);
        dash_table.setRowSelectionAllowed(false);
        dash_table.getTableHeader().setReorderingAllowed(false);
        dash_table.getTableHeader().setResizingAllowed(false);
        dash_table.setFont(new Font("Arial", Font.PLAIN, 12));
        Object[] column = {"       Position Code","          Job Title", "    Responsibilities", "            Salary"};
        model.setColumnIdentifiers(column);
        final Object[] row = new Object[4];
        model.setColumnIdentifiers(column);      
        scrollPane.setViewportView(dash_table);

	    
	    // Applicant Count 

	    AppStatus = new JPanel();
        AppStatus.setBounds(680, 230, 593, 218);
        AppStatus.setBackground(Color.WHITE);
        ExecutiveDashboard.getContentPane().add(AppStatus);
        AppStatus.setLayout(null);


        // BUTTONS ====================================================================================

        //JOB POSTING
        JButton btn_JobPosting = new JButton("");
        btn_JobPosting.setBorder(null);
        btn_JobPosting.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	
            	JobPosting jobPosting = new JobPosting();
            	jobPosting.JobPosting.setVisible(true);
                ExecutiveDashboard.dispose();
            }
        });
        btn_JobPosting.setIcon(new ImageIcon("C:\\Users\\tyrel\\Downloads\\NCVAProject\\NCVASystemUI\\Buttons\\ExecutiveDash\\POSTING(ADMIN)_ .png"));
        btn_JobPosting.setBackground(new Color(11, 20, 10));
        btn_JobPosting.setBounds(1178, 96, 102, 40);
        ExecutiveDashboard.getContentPane().add(btn_JobPosting);

        //LOG OUT
        JButton btn_LogOut = new JButton("");
        btn_LogOut.setBorder(null);
        btn_LogOut.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	
        		AdminLogin AdminLog = new AdminLogin();
				AdminLog.setVisible(true);
				ExecutiveDashboard.dispose();
            }
        });
        btn_LogOut.setIcon(new ImageIcon("C:\\Users\\tyrel\\Downloads\\NCVAProject\\NCVASystemUI\\Buttons\\ExecutiveDash\\LOG OUT(ADMIN)_ .png"));
        btn_LogOut.setBounds(1069, 96, 97, 40);
        ExecutiveDashboard.getContentPane().add(btn_LogOut);
        
        JButton btnViewJobsButton = new JButton("View / Refresh");
        btnViewJobsButton.setBounds(273, 173, 148, 29);
        btnViewJobsButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Clear table first
		    	model.setRowCount(0);
	        	String url = "jdbc:sqlserver://DESKTOP-8OC2E7P\\sqlexpress:1433;databaseName=NCVADatabase2;integratedSecurity=true;encrypt=true;trustServerCertificate=true;authenticationScheme=NativeAuthentication";

				try {
					Connection connection = DriverManager.getConnection(url);
					
					Statement st = connection.createStatement();
					
					String sqlQuery = "SELECT * FROM JobPosition";
					ResultSet rs = st.executeQuery(sqlQuery);
					
					while (rs.next()) {
						// Data from the database will continue to be added until it reaches the end
						String jobID = String.valueOf(rs.getInt("JobID")); // Conversion due to int value
						String jobTitle = rs.getString("Title");
						String jobTask = rs.getString("Task"); 
						String jobSalary = String.valueOf(rs.getFloat("Salary"));
						
						// String array to store data into the JTable
						String tableData[] = {jobID, jobTitle, jobTask, jobSalary};
						
						
						// Add string array data into jtable
						model.addRow(tableData);
					} // Add code to clear everything off the table in case the user presses the button multiple times
					
					connection.close();
				} catch(Exception ex) {
					ex.printStackTrace();
				}
			}
		});
        ExecutiveDashboard.getContentPane().add(btnViewJobsButton);
        
        
        
        JButton btnViewApplicantsButton = new JButton("View / Refresh");
        btnViewApplicantsButton.setBounds(932, 173, 148, 29);
        btnViewApplicantsButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				applicantTableModel.setRowCount(0);
	        	String url = "jdbc:sqlserver://DESKTOP-8OC2E7P\\sqlexpress:1433;databaseName=NCVADatabase2;integratedSecurity=true;encrypt=true;trustServerCertificate=true;authenticationScheme=NativeAuthentication";

				try {
		    		Connection connection = DriverManager.getConnection(url);
		    		
		    		String applicantsQuery = "SELECT JobApplication.JobApplicationID, Applicant.Name, JobPosition.Title, JobApplication.Status "
		    				+ "FROM JobApplication JOIN Applicant ON JobApplication.ApplicantID = Applicant.ApplicantID JOIN JobPosition ON "
		    				+ "JobApplication.JobID = JobPosition.JobID;";
		    		
		    		PreparedStatement p1 = connection.prepareStatement(applicantsQuery);
		    		ResultSet tableInfo = p1.executeQuery();
		    		ResultSetMetaData timd = tableInfo.getMetaData();
		    		
		    		int columns = timd.getColumnCount();
		    		String[] columnNames = new String[columns];
		    		
		    		for (int i = 0; i < columns; i++) {
		    			columnNames[i] = timd.getColumnName(i + 1);
		    		}
		    		
		    		applicantTableModel.setColumnIdentifiers(columnNames);
		    		
		    		String applicationID = "", name = "", title = "", status = "";
		    		while (tableInfo.next()) {
		    			applicationID = Integer.toString(tableInfo.getInt(1));
		    			name = tableInfo.getString(2);
		    			title = tableInfo.getString(3);
		    			status = tableInfo.getString(4);
		    			String[] row = {applicationID, name, title, status};
		    			applicantTableModel.addRow(row);
		    		}
		    		
		    		
		    		p1.close();
		    		connection.close();

		    	} catch (Exception ex) {
		    		ex.printStackTrace();
		    	} 
			}
		});
        ExecutiveDashboard.getContentPane().add(btnViewApplicantsButton);
        
        textFieldName = new JTextField();
        textFieldName.setBounds(689, 556, 271, 36);
        ExecutiveDashboard.getContentPane().add(textFieldName);
        textFieldName.setEditable(false);
        
        textFieldPosition = new JTextField();
        textFieldPosition.setBounds(689, 647, 271, 36);
        ExecutiveDashboard.getContentPane().add(textFieldPosition);
        textFieldPosition.setEditable(false);
        
        String[] applicationStatuses = {"Pending", "Accepted", "Rejected"};
        DefaultComboBoxModel<String> comboBoxModel = new DefaultComboBoxModel<>(applicationStatuses);
        JComboBox<String> comboBox = new JComboBox<String>(comboBoxModel);
        comboBox.setBounds(998, 562, 179, 27);
        ExecutiveDashboard.getContentPane().add(comboBox);
        
        JButton btnUpdate = new JButton("Update");
        btnUpdate.setBounds(998, 647, 117, 29);
        btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				// Check for selected row on the table
				// If yes, proceed to update the table
				int i = applicantTable.getSelectedRow();
				
				
				if (i >= 0) {
					if (!(textFieldName.getText().isBlank()) && !(textFieldPosition.getText().isBlank()) ) {
						
						String applicationID = (String) applicantTable.getValueAt(i, 0);
						String updatedStatus = (String) comboBox.getSelectedItem();
						
			        	String url = "jdbc:sqlserver://DESKTOP-8OC2E7P\\sqlexpress:1433;databaseName=NCVADatabase2;integratedSecurity=true;encrypt=true;trustServerCertificate=true;authenticationScheme=NativeAuthentication";

						try {
			            	Connection connection = DriverManager.getConnection(url);
			            		
			            	String updatedQuery = "UPDATE JobApplication SET Status = ? WHERE JobApplicationID = ?;";	           		
			           		
			           		PreparedStatement update = connection.prepareStatement(updatedQuery);
			           		
			           		update.setString(1, updatedStatus);
			           		update.setString(2, applicationID);
			           		
			           		int x = update.executeUpdate();

			           		if (x == 0) {
			           			JOptionPane.showMessageDialog(btnUpdate, "An error has occured: Failed to update applicant's status.");
			           		} else {
			           			JOptionPane.showMessageDialog(btnUpdate, "Successfully updated the applicant's status!");
		            		}
			           		update.close();
		            		connection.close();
		            	} catch (Exception ex) {
		            		ex.printStackTrace();
		            	}
						
					} else {
						JOptionPane.showMessageDialog(btnUpdate, "Make sure that there are no empty values.");
					}
			    } else {
					JOptionPane.showMessageDialog(btnUpdate, "Please select a line in the table first");
			    }
						
			}
		});
        ExecutiveDashboard.getContentPane().add(btnUpdate);
        
        // APPLICANT TABLE
        applicantTable = new JTable();
        applicantTable.setBounds(680, 233, 593, 357);
        
        applicantTableModel = (DefaultTableModel) applicantTable.getModel();
        
        applicantTable.setModel(applicantTableModel);
        
        
        applicantScrollPane = new JScrollPane();
        applicantScrollPane.setBounds(680, 231, 593, 217);
        applicantScrollPane.setViewportView(applicantTable);
        ExecutiveDashboard.getContentPane().add(applicantScrollPane);
        
        applicantTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				int i = applicantTable.getSelectedRow();
				textFieldName.setText(applicantTableModel.getValueAt(i,1).toString());
				textFieldPosition.setText(applicantTableModel.getValueAt(i,2).toString());
				comboBox.getModel().setSelectedItem(applicantTableModel.getValueAt(i,3).toString());
			}
		});
        
        JLabel lblName = new JLabel("Name of Applicant");
        lblName.setBounds(689, 528, 131, 16);
        ExecutiveDashboard.getContentPane().add(lblName);
        
        JLabel lblAppliedPosition = new JLabel("Applied Position");
        lblAppliedPosition.setBounds(689, 619, 110, 16);
        ExecutiveDashboard.getContentPane().add(lblAppliedPosition);
        
        JLabel lblStatus = new JLabel("Status");
        lblStatus.setBounds(998, 528, 45, 16);
        ExecutiveDashboard.getContentPane().add(lblStatus);
        
        String[] statusFilters = {"No Filter", "Pending", "Accepted", "Rejected"};
        DefaultComboBoxModel<String> comboBoxFilterModel = new DefaultComboBoxModel<>(statusFilters);
        JComboBox<String> comboBoxStatusFilter = new JComboBox<String>(comboBoxFilterModel);
        comboBoxStatusFilter.setBounds(1094, 174, 179, 27);
        comboBoxStatusFilter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String categoryChosen = (String) comboBoxStatusFilter.getSelectedItem();
				if (!categoryChosen.equals("No Filter")) {
					filter((String) comboBoxStatusFilter.getSelectedItem());
				} else {
					filter("\\w+\\s*");
				}
			}
		});
        ExecutiveDashboard.getContentPane().add(comboBoxStatusFilter);
        
        

        // BACKGROUND====================================================================================

        JLabel ExecutiveDash_BG = new JLabel("");
        ExecutiveDash_BG.setIcon(new ImageIcon("C:\\Users\\tyrel\\Downloads\\NCVAProject\\NCVASystemUI\\Pages\\EXECUTIVE DASHBOARD (ADMIN)2.png"));
        ExecutiveDash_BG.setBounds(0, 0, 1300, 800);
        ExecutiveDashboard.getContentPane().add(ExecutiveDash_BG);
        

    }
    
    private void filter(String query) {
		DefaultTableModel model = (DefaultTableModel)applicantTable.getModel();
		TableRowSorter<DefaultTableModel> tr = new TableRowSorter<DefaultTableModel>(model);
		applicantTable.setRowSorter(tr);
		
		tr.setRowFilter(RowFilter.regexFilter("(?i)" + query));
	}
    
    
}